# MTG Deck Builder Task

- Run the app 
```bash
npm install
npm run start
```

- Make cards clickable. On click show card details
on the CardView.
- On Card view click on the card should add it to the Deck View
- In deck view we need a possibility to remove cards
- The widgets on the left should be updated when deck is updated.

[Link to the API docs](https://docs.magicthegathering.io/#api_v1cards_list)